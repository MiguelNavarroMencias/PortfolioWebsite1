#include <iostream>
#include <iomanip>
#include "Data.h"
using namespace std;

void Data::static_report2() // function to print static report 2
//displays balance and interest with additional montly deposit
{
	double money = m_initialAmount; // assign initial amount of money
	cout << "   Balance and Interest With Additional Monthly Deposits   " << endl; //print table
	cout << "==============================================================" << endl;
	cout << " Year         Year End Balance      Year End Earned Interest  " << endl;
	cout << "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - " << endl;
	for (int i = 1; i < m_years + 1; i++) //for loop to iterate the amount of years given by user
	{
		double AnnualInt = 0;// assign initial annual interest
		for (int j = 0; j < 12; j++) // for loop to calculate month end total
		{
			double IntAmount = (money + m_monthlyD) * ((m_annualI / 100) / 12); // formula for interest earned
			AnnualInt = AnnualInt + IntAmount;//interest earned per year
			money = money + m_monthlyD + IntAmount; //final compensation 
		}
		//print data
		cout << "  " << i << "                   " << "$" << fixed <<setprecision(2) << money << "                   " <<"$" << AnnualInt << "  " << endl;
		

	}
}
