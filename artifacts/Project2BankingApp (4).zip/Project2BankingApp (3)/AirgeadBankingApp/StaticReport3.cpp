#include <iostream>
#include <iomanip>
#include "Data.h"
using namespace std;

void Data::static_report3() { //static report showing total compensation summary
	double money = m_initialAmount;
	double money1 = m_initialAmount;
	double AnnualInt = 0;

	cout << "   Total Compensation   " << endl; //print table
	cout << "==============================================================" << endl;
	
	for (int i = 1; i < m_years; i++) {
		double IntAmount = (money + m_monthlyD) * ((m_annualI / 100) / 12); // formula for interest earned
		AnnualInt = AnnualInt + IntAmount;//interest earned per year
		money = money + m_monthlyD + IntAmount; //final compensation 
	}

	for (int i = 1; i < m_years + 1; i++) // for loop to iterate the amount of years given from user
	{
		double annualInt = money1 * (m_annualI / 100); // formula for annual interest obtained
		money1 = money1 + annualInt;// final compensation
	}

	double totalComp1 = money * m_years;
	double totalComp2 = money1 * m_years;

	cout << "Total Compensation with a montly deposit for " << m_years << " years: " << totalComp1;
	cout << endl;
	cout << endl;
	cout << endl;
	cout << "Total Compensation without a montly deposit for " << m_years << " years: " << totalComp2;


	


}

