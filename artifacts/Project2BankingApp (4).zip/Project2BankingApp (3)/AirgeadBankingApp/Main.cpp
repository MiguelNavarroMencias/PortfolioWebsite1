#include <iostream>
#include <iomanip>
#include "Data.h"
using namespace std;

int main() {
	Data MyInvestment; // variable of the class type to create object
	// Data object named MyInvestment

	//declaration of variables to get and store user inputs
	int initial;
	int amount;
	int interest;
	int numYears;

	
	Menu(); //call function menu
	cout << endl;

	//print table
	cout << "************************************" << endl;
	cout << "***********" << " Data Input " << "*************" << endl;
	
	cout << "Initial Investment Amount: "; //get initial investment amount from user
	cin >> initial;
	MyInvestment.SetinitialInvestmentAmount(initial); // calls SetinitialInvestmentAmount function

	cout << "Monthly Deposit: ";// get monthly depoit from user
	cin >> amount;
	MyInvestment.SetmonthlyDeposit(amount); //calls SetmonthlyDeposit function

	cout << "Annual Interest: "; //get Annual interest from user
	cin >> interest;
	MyInvestment.SetannualInterest(interest);// calls SetannualInterest function

	cout << "Number of years: ";// get number of years from user
	cin >> numYears;
	MyInvestment.SetnumberYears(numYears); //calls SetnumberYears function 

	system("pause"); //pasue system until user press any key 

	cout << "\033[2J\033[4;1H"; //ANSI escape code to clear the screen from top to bottom and positions the coursor

	MyInvestment.static_report1();// calls function static report1 
	cout << endl;
	cout << endl;// print space between reports
	cout << endl;
	MyInvestment.static_report2(); //calls function static report2
	cout << endl;
	cout << endl;// print space between reports
	cout << endl;

	MyInvestment.static_report3();
	cout << endl;
	cout << endl;// print space between reports
	cout << endl;
	cout << endl;
	cout << endl;// print space between reports
	cout << endl;
	cout << endl;
	cout << endl;// print space between reports
	cout << endl;
}