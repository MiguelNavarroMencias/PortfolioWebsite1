#include <iostream>
using namespace std;

#include "Data.h"

// scope resolution operator to define member functions from class Data
void Data::SetinitialInvestmentAmount(int InitialAmount) 
{
	m_initialAmount = InitialAmount;
}

void Data::SetmonthlyDeposit(int Rdeposit) 
{
	m_monthlyD = Rdeposit;
}

void Data::SetannualInterest(int InterestRate) 
{
	m_annualI = InterestRate;
}

void Data::SetnumberYears(int Years)
{
	m_years = Years;
}

double Data::GetinitialInvestmentAmount() 
{
	return m_initialAmount;
}
double Data::GetmonthlyDeposit() 
{
	return m_monthlyD;
}
double Data::GetannualInterest() 
{
	return m_annualI;
}
int Data::GetnumberYears() 
{
	return m_years;
}
void Menu();