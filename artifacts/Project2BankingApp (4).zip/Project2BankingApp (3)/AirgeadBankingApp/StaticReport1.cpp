#include <iostream>
#include <iomanip>
#include "Data.h"
using namespace std;

void Data::static_report1() //function to print static report 1
//displays balance and interest without additional monthly deposit
{
	double money1 = m_initialAmount; //assign initial amount of money
	//print table
	cout << "   Balance and Interest Without Additional Monthly Deposits   " << endl;
	cout << "==============================================================" << endl;
	cout << " Year         Year End Balance      Year End Earned Interest  " << endl;
	cout << "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - " << endl;
	for (int i = 1; i < m_years + 1; i++) // for loop to iterate the amount of years given from user
	{
		double annualInt = money1  * (m_annualI / 100); // formula for annual interest obtained
		money1 = money1 + annualInt;// final compensation
		//print data
		cout << "  " << i << "                   " << "$" << fixed << setprecision(2) << money1 << "                      " << "$" << annualInt << "  " << endl;
		
		
	}
}