#include <iostream>
#include "Data.h"
using namespace std;

void Menu() //define menu  function to print table with options
{
	cout << "************************************" << endl;
	cout << "***********" << " Data Input " << "*************" << endl;

	cout << "Initial Investment Amount: ";
	cout << endl;

	cout << "Monthly Deposit: ";
	cout << endl;

	cout << "Annual Interest: ";
	cout << endl;

	cout << "Number of years: ";
	cout << endl;
	system("pause"); //pause system until user press any key

}