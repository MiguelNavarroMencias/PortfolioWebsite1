#pragma once
#ifndef DATA_H
#define DATA_H
class Data //info about the data needed for the reports
	//declaration of public member functions
	//Mutators and Accessors
{
public:
	void SetinitialInvestmentAmount(int InitialAmount);
	void SetmonthlyDeposit(int Rdeposit); 
	void SetannualInterest(int InterestRate);
	void SetnumberYears(int Years);
	double GetinitialInvestmentAmount();
	double GetmonthlyDeposit();
	double GetannualInterest();
	int GetnumberYears();
	void static_report1();
	void static_report2();
	void static_report3();
	
	//declaration of private member variables
private:
	double m_initialAmount;
	double m_monthlyD;
	double m_annualI;
	int m_years;
};
void Menu();// declaration of function menu

#endif


